import 'package:flame/components.dart';
import 'package:okeyix/game/rack/rack_config.dart';
/// Fixed-resolution 1600x900 game-world coordinates. All play targets
/// use this shared geometry; screen scaling is handled by Flame camera.
abstract final class TableLayout {
  static Vector2 get pile => Vector2(735, 445);
  static Vector2 get indicator => Vector2(855, 445);
  // Two-player table: upper-right is opponent, lower-left is local player.
  // The unused seats retain safe positions for legacy index handling.
  static List<Vector2> get discards => [
    Vector2(390, 365), Vector2(1180, 365),
    Vector2(390, 495), Vector2(1180, 495),
  ];
  // Keep tile slots untouched. Fit the existing walnut artwork to their rows.
  // Slot centres: bottom row y=741, upper row y=605; lower edges y=800/664.
  // Artwork shelf edges at ~184/419 and ~318/419 of image height.
  static const double rackWidth = 1300;
  static const double rackHeight = 390;
  static Vector2 get rackCenter => Vector2(825, 706);

  // Separate areas: avatar x=10..155; rack x=155..1455; controls x=1460..1585.
  static const double avatarLeft = 8;
  static const double avatarTop = 548;
  static const double avatarWidth = 220;
  static const double controlsX = 1420;
  static const double controlsY = 545;
  static const double controlWidth = 168;
  static const double controlHeight = 66;
  static const double controlGap = 12;

  // The actual tile geometry remains owned by RackConfig/RackSlotGenerator.
  static double get rackTileLeft => rackCenter.x - rackWidth / 2 +
      RackConfig.designLeftInset * (rackWidth / RackConfig.designWidth);
  static double get rackTileRight => rackTileLeft +
      (RackConfig.columns * RackConfig.designTileWidth +
       (RackConfig.columns - 1) * RackConfig.designColumnGap) *
      (rackWidth / RackConfig.designWidth);
}
