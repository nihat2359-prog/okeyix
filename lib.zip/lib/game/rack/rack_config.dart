/// Approved HTML preview, 1500x419 rack image coordinates.
/// Values below are mapped to Flame world units by the rack scale.
class RackConfig {
  static const int columns = 13;
  static const int rows = 2;
  static const double designWidth = 1500;
  static const double designHeight = 419;
  static const double designTileWidth = 102;
  static const double designTileHeight = 120;
  static const double designColumnGap = -3;
  static const double designLeftInset = 103;
  static const double designUpperY = 65;
  static const double designLowerY = 192;
  static const double designFontSize = 54;
  static const int designFontWeight = 800;
  static const double designNumberY = 60;
  static const double designDotY = 88;
  static const double designDotRadius = 10;
  static const double designYellowHue = 48;

  // TableLayout.rackWidth = 1300, rackHeight = 390.
  // Rack PNG uses non-uniform scaling in the existing game; preserve it.
  static const double scaleX = 1300 / designWidth;
  static const double scaleY = 390 / designHeight;
  static const double tileWidth = designTileWidth * scaleX;
  static const double tileHeight = designTileHeight * scaleY;
  static const double gap = designColumnGap * scaleX;
  static const double rowGap = (designLowerY - designUpperY) * scaleY - tileHeight;
  // Kept for any legacy references; slot generator uses design coordinates.
  static const double rackLeftOffset = 175 + designLeftInset * scaleX;
  static const double rackBottomOffset = 900 - (511 + designLowerY * scaleY + tileHeight);
}
