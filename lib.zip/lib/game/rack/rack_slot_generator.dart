import 'package:flame/components.dart';
import '../layout/table_layout.dart';
import 'rack_config.dart';

/// Slot centers use the exact same rack PNG coordinate transform as HTML.
/// Index order is unchanged: bottom row 0..12, upper row 13..25.
class RackSlotGenerator {
  static List<Vector2> generate() {
    final left = TableLayout.rackCenter.x - TableLayout.rackWidth / 2;
    final top = TableLayout.rackCenter.y - TableLayout.rackHeight / 2;
    final sx = TableLayout.rackWidth / RackConfig.designWidth;
    final sy = TableLayout.rackHeight / RackConfig.designHeight;
    final result = <Vector2>[];
    for (var row = 0; row < RackConfig.rows; row++) {
      final y = row == 0 ? RackConfig.designLowerY : RackConfig.designUpperY;
      for (var col = 0; col < RackConfig.columns; col++) {
        final x = RackConfig.designLeftInset + col *
            (RackConfig.designTileWidth + RackConfig.designColumnGap);
        result.add(Vector2(
          left + (x + RackConfig.designTileWidth / 2) * sx,
          top + (y + RackConfig.designTileHeight / 2) * sy,
        ));
      }
    }
    return result;
  }
}
