import 'package:okeyix/game/layout/table_layout.dart';
import 'package:flame/collisions.dart';
import 'package:flame/effects.dart';
import 'package:flame/events.dart';
import 'package:flutter/material.dart';
import 'package:okeyix/game/theme_flags.dart';

import 'package:flame/components.dart';
import 'okey_game.dart';

class Stage extends Component with HasGameReference<OkeyGame> {
  late final PositionComponent _rack;
  bool _buttonsShown = false;

  @override
  Future<void> onLoad() async {
    final image = await game.images.load('rack.png');

    _rack = PositionComponent(
      size: Vector2(TableLayout.rackWidth, TableLayout.rackHeight),
      position: TableLayout.rackCenter,
      anchor: Anchor.center,
    );

    _rack.add(
      SpriteComponent(
        sprite: Sprite(image),
        size: _rack.size,
        anchor: Anchor.center,
        position: _rack.size / 2,
      ),
    );
    if (false) { // no neon overlay on natural walnut rack
      _rack.add(RackCinematicFx(size: _rack.size, position: _rack.size / 2));
    }

    _rack.priority = 0;
    add(_rack);
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (_buttonsShown || !game.gameStarted) return;
    _buttonsShown = true;
    _spawnAnimatedRackButtons();
  }

  Future<void> _spawnAnimatedRackButtons() async {
    final rackTop = _rack.position.y - (_rack.size.y / 2);
    final rackLeft = _rack.position.x - (_rack.size.x / 2);
    final rackRight = _rack.position.x + (_rack.size.x / 2);
    // The left rack wing is reserved for the local player's avatar card.
    // Keep all three existing actions together on the right rack wing.
    final buttonSize = Vector2(TableLayout.controlWidth, TableLayout.controlHeight);
    const gap = TableLayout.controlGap;
    final rightX = TableLayout.controlsX;
    final firstY = TableLayout.controlsY;
    final targets = [
      Vector2(rightX, firstY),
      Vector2(rightX, firstY + buttonSize.y + gap),
      Vector2(rightX, firstY + (buttonSize.y + gap) * 2),
    ];

    final seri = RackActionButton(
      label: 'Seri Diz',
      targetPosition: targets[0],
      startPosition: Vector2(rightX + 55, targets[0].y),
      size: buttonSize,
      onTap: () => game.arrangeSerial(),
    );
    final cifte = RackActionButton(
      label: 'Çifte Diz',
      targetPosition: targets[1],
      startPosition: Vector2(rightX + 55, targets[1].y),
      size: buttonSize,
      onTap: () => game.arrangePairs(),
    );
    final git = RackActionButton(
      label: 'Çifte Git',
      targetPosition: targets[2],
      startPosition: Vector2(rightX + 55, targets[2].y),
      size: buttonSize,
      onTap: () => game.requestDoubleMode(),
    );

    add(seri);
    add(cifte);
    add(git);
  }
}

class RackCinematicFx extends PositionComponent {
  RackCinematicFx({required Vector2 size, required Vector2 position}) {
    this.size = size;
    this.position = position;
    anchor = Anchor.center;
  }

  @override
  void render(Canvas canvas) {
    final rect = Rect.fromLTWH(0, 0, size.x, size.y);
    final glowA = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0x6627D8FF), Color(0x33FF5BF1), Color(0x4D2AB3FF)],
        stops: [0.0, 0.48, 1.0],
      ).createShader(rect);
    canvas.drawRect(rect, glowA);

    final stripTop = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [Color(0x0064F3FF), Color(0xAA64F3FF), Color(0x0064F3FF)],
      ).createShader(Rect.fromLTWH(0, size.y * 0.28, size.x, 6));
    canvas.drawRect(Rect.fromLTWH(0, size.y * 0.28, size.x, 6), stripTop);

    final stripMid = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [Color(0x00FF57E8), Color(0x99FF57E8), Color(0x00FF57E8)],
      ).createShader(Rect.fromLTWH(0, size.y * 0.52, size.x, 5));
    canvas.drawRect(Rect.fromLTWH(0, size.y * 0.52, size.x, 5), stripMid);
  }
}

class RackActionButton extends PositionComponent with TapCallbacks {
  final String label;
  final Vector2 targetPosition;
  final Vector2 startPosition;
  final VoidCallback onTap;
  bool _pressed = false;
  late final TextPaint _textPaint;
  late final double _lineHeight;

  RackActionButton({
    required this.label,
    required this.targetPosition,
    required this.startPosition,
    required Vector2 size,
    required this.onTap,
  }) : super(
         position: startPosition,
         size: size,
         anchor: Anchor.topLeft,
         priority: 10,
       );

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _textPaint = TextPaint(
      style: TextStyle(
        color: Color(0xFFF6D783),
        fontSize: size.y >= 150 ? 30 : 24,
        fontWeight: FontWeight.w700,
        height: 1.0,
      ),
    );
    _lineHeight = size.y >= 150 ? 34 : 24;
    add(RectangleHitbox(size: size, anchor: Anchor.topLeft));

    add(
      MoveEffect.to(
        targetPosition,
        EffectController(duration: 0.32, curve: Curves.easeOutBack),
      ),
    );
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final rect = Rect.fromLTWH(0, 0, size.x, size.y);
    final r = RRect.fromRectAndRadius(rect, const Radius.circular(16));

    final body = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF2A352E), Color(0xFF0F1612)],
      ).createShader(rect);
    final border = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFFF0CC7D), Color(0xFFB8842D)],
      ).createShader(rect)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2;

    final inner = Paint()
      ..color = const Color(0x33FFF6D8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    final gloss = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0x44FFF2CD), Color(0x00FFF2CD)],
        stops: [0.0, 0.65],
      ).createShader(Rect.fromLTWH(0, 0, size.x, size.y * 0.55));

    if (_pressed) {
      canvas.save();
      final cx = size.x / 2;
      final cy = size.y / 2;
      canvas.translate(cx, cy);
      canvas.scale(0.98, 0.98);
      canvas.translate(-cx, -cy);
    }
    canvas.drawRRect(r, body);
    canvas.drawRRect(r, gloss);
    canvas.drawRRect(r, border);
    canvas.drawRRect(r.deflate(5), inner);
    // Render labels on one line, sized to the actual button width.
    final textPainter = TextPainter(
      text: TextSpan(text: label, style: const TextStyle(
        color: Color(0xFFF6D783), fontSize: 23, fontWeight: FontWeight.w600,
      )),
      textDirection: TextDirection.ltr,
      maxLines: 1,
    )..layout(maxWidth: size.x - 18);
    final x = (size.x - textPainter.width) / 2;
    final y = (size.y - textPainter.height) / 2;
    textPainter.paint(canvas, Offset(x, y));
    if (_pressed) canvas.restore();
  }

  @override
  void onTapDown(TapDownEvent event) {
    if (_pressed) return;
    _pressed = true;
    add(
      ScaleEffect.to(
        Vector2.all(0.96),
        EffectController(duration: 0.06, curve: Curves.easeOut),
      ),
    );
    onTap();
  }

  @override
  void onTapUp(TapUpEvent event) {
    _pressed = false;
    add(
      ScaleEffect.to(
        Vector2.all(1.0),
        EffectController(duration: 0.08, curve: Curves.easeOut),
      ),
    );
  }

  @override
  void onTapCancel(TapCancelEvent event) {
    _pressed = false;
    add(
      ScaleEffect.to(
        Vector2.all(1.0),
        EffectController(duration: 0.08, curve: Curves.easeOut),
      ),
    );
  }
}
